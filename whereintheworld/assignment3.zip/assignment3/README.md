I was able to correctly implement the POST API and tested it with the marauder's map assignment 2.  The GET locations and redline worked as well to show the list of the list of people in the database and the up to date map of the redline.  I also implemented the index page to show the name, location and timestamp of users.

I spent probably up to 30-40 hours, most of which not being able to figure out mongo.  I was being stupid, and not turning on mongod correctly.

I worked with Leo Choi and Charlie Colley on this project.

